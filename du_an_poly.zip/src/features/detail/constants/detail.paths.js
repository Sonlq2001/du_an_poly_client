export const DETAIL_PATHS = {
  DETAIL_PRODUCT: '/product/:id',
};
