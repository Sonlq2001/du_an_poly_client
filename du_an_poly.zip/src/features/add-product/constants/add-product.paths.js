export const ADD_PRODUCT_PATHS = {
  ADD_PRODUCT: '/product/update/:token',
};
