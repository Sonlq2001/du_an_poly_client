export const HOME_PATH = {
  HOME: '/',
};
