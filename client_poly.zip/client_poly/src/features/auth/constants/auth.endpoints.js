export const AUTH_ENDPOINTS = {
  POST_ACCESS_TOKEN: '/callback/google',
  POST_LOGOUT: '/logout',
};
