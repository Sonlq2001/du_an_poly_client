export const CATEGORY_ENDPOINTS = {
  GET_PRODUCTS: '/products',
  GET_MAJORS: '/majors',
};
