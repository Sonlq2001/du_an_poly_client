export const HOME_PATH = {
  GET_DATA: '/users',
};
