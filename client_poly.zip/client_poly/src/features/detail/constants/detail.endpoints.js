export const DETAIL_ENDPOINTS = {
  GET_PRODUCT_DETAIL: '/products/:id',
};
