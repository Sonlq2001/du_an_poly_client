export const ADD_PRODUCT_ENDPOINTS = {
  GET_PRODUCT_TYPES: '/product_types',
  POST_ADD_PRODUCT: '/products',
};
export const REMOVE_IMG = {
  REMOVE: '/products/deleteimage',
};
export const REMOVE_DOCUMENT = {
  REMOVE: '/products/deletedocument',
};
