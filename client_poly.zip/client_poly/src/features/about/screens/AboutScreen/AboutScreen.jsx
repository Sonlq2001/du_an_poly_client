import React from 'react';

const AboutScreen = () => {
  return <div className="container">le quang son</div>;
};

export default AboutScreen;
