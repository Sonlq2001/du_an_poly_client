export const initForm = {
  name: '',
  video_url: '',
  product_type_id: '',
  class: 'pt12365',
  image_url: '',
  resource_url: '',
  students: null,
  galleries: [],
  description: '',
  status: 1,
  token: '',
};
