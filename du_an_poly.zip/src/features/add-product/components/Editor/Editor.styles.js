import styled from 'styled-components';
export const WarEditor = styled.div`
  .ck-blurred,
  .ck-content {
    height: 60rem;
  }
`;
