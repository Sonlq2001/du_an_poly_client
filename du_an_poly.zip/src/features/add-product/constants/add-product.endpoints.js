export const ADD_PRODUCT_ENDPOINTS = {
  GET_PRODUCT_TYPES: '/product_types',
  POST_ADD_PRODUCT: '/products',
};
