import React from 'react';

const Layout404 = ({ children }) => {
  return (
    <div>
      {children}
    </div>
  );
};

export default Layout404;
